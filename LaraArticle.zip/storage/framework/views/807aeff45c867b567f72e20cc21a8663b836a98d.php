<?php $__env->startSection('title_and_meta'); ?>
	<?php
		$konten = $post->content;
		$konten = strip_tags(str_replace("&nbsp;","",$konten));
	?>

	<title><?php echo e($post->title); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>
	<meta name="description" content="<?php echo e($konten); ?>" />

	<!-- Social Meta Tags -->
  	<meta property="og:title" content="<?php echo e($post->title); ?> | <?php echo e(config('app.name', 'Laravel')); ?>"/>
  	<meta property="og:type" content="article"/>
  	<meta property="og:url" content="<?php echo e(url()->current()); ?>" />
  	<meta property="og:description" content="<?php echo e($konten); ?>" />
  	<?php if($post->image !== null): ?>
  	<meta property="og:image" content="<?php echo e(asset('images/post-image/'.$post->image)); ?>" />
  	<?php endif; ?>

  	<!-- Twitter Meta Cards -->
  	<meta name="twitter:card" content="summary" />
  	<meta name="twitter:url" content="<?php echo e(url()->current()); ?>" />
  	<meta name="twitter:title" content="<?php echo e($post->title); ?> | <?php echo e(config('app.name', 'Laravel')); ?>" />
  	<meta name="twitter:description" content="<?php echo e($konten); ?>" />
  	<?php if($post->image !== null): ?>
  	<meta name="twitter:image" content="<?php echo e(asset('images/post-image/'.$post->image)); ?>" />
  	<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fb-comment'); ?>
	<?php if($post->aired == 1): ?>
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.10&appId=1831643150498888";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container wrapper">
	<div class="callout my2"></div>
	<div class="card post mt2">
		<?php if($post->image !== null): ?>
		<div class="post__image">
			<img src="<?php echo e(asset('images/post-img/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>">
		</div>
		<?php endif; ?>

		<div class="post__content clearfix">
			<div class="col lg-col-12">
				<header class="post__header">
					<span class="label">
						<a href="#"><?php echo e($post->namaKategori->category); ?></a>
						<span class="text--gray"> / </span>
						<span class="text--gray"><?php echo e($post->created_at->format('j F, Y')); ?></span>
					</span>
					<h1 class="post__title"><?php echo e($post->title); ?></h1>
				</header>
				<?php echo $post->content; ?>

			</div>
		</div>

		<div class="post__footer">
			<div class="post__author">
				<?php if($post->namaPenulis->image !== null): ?>
				<img class="author__image" src="<?php echo e(asset('images/user-pp/'.$post->namaPenulis->image)); ?>">
				<?php else: ?>
				<img class="author__image" src="<?php echo e(asset('images/user-pp/user.png')); ?>">
				<?php endif; ?>
				<div class="author__content">
					<h4 class="author__name">By <a href="#"><?php echo e($post->namaPenulis->name); ?></a></h4>
				</div>
			</div>
			<ul class="tags">
				<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="tag">
					<a href="#" class="tag__link"><?php echo e($tag->tag); ?></a>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
</div>
<?php if($post->aired == 1): ?>
<div class="wrapper bg--white mt4 pt6 pb6">
	<div class="container">
		<div class="fb-comments" data-href="<?php echo e(route('home.read', ['slug' => $post->slug])); ?>" data-width="100%" data-numposts="5"></div>
	</div>
</div>
<?php else: ?>
<br><br>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>