<?php $__env->startSection('plugin'); ?>
<style type="text/css">
  .modal-backdrop{display:none}.note-placeholder{position:absolute;top:90px;left:95px;font-size:34px;color:#e4e5e7;display:none;pointer-events:none}.note-editor .note-toolbar{background:#F5F5F5;border-bottom:1px solid #c2cad8}.summernote .panel-primary>.panel-heading{color:#333;background-color:#f5f5f5;border-color:#ddd}.summernote .btn-default{background:#fff!important}.summernote .btn-default:hover{background:#4285F4!important}.summernote .btn-default.active{background:#0B51C5!important}.summernote .btn{color:#000!important;background-color:#fff;border:1px solid #ccc;white-space:nowrap!important;padding:6px 12px;font-size:14px;line-height:1.42857;user-select:none;box-shadow:none!important}.summernote .btn:hover{cursor:pointer}
</style>

<style type="text/css">
  #progress-wrp {
    border: 1px solid #0099CC;
    padding: 1px;
    position: relative;
    border-radius: 3px;
    margin: 10px;
    text-align: left;
    background: #fff;
    box-shadow: inset 1px 3px 6px rgba(0, 0, 0, 0.12);
}
#progress-wrp .progress-bar{
    height: 20px;
    border-radius: 3px;
    background-color: #f39ac7;
    width: 0;
    box-shadow: inset 1px 1px 10px rgba(0, 0, 0, 0.11);
}
#progress-wrp .status{
    top:3px;
    left:50%;
    position:absolute;
    display:inline-block;
    color: #000000;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Breadcrumb -->
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Home</li>
</ol>
<div class="container-fluid">
    <div class="animated fadeIn">
        <?php if(Session::get('Error')): ?>
          <div class="row">
              <div class="alert alert-danger col-12 text-center" role="alert">
                <?php echo e(Session::get('Error')); ?>

              </div>
          </div>
        <?php endif; ?>
        <?php if(count($tags) < 1 && count($categories) > 0): ?>
          <div class="row">
              <div class="alert alert-warning col-12" role="alert">
                Anda belum mendaftarkan satupun tag, diharapkan mengisi terlebih dahulu karna akan dibutuhkan dalam pembuatan artikel
              </div>
          </div>
        <?php endif; ?>

        <?php if(count($categories) < 1 && count($tags) > 0): ?>
          <div class="row">
              <div class="alert alert-warning col-12" role="alert">
                Anda belum mendaftarkan satupun category, diharapkan mengisi terlebih dahulu karna akan dibutuhkan dalam pembuatan artikel
              </div>
          </div>
        <?php endif; ?>

        <?php if(count($categories) < 1 && count($tags) < 1): ?>
          <div class="row">
              <div class="alert alert-warning col-12" role="alert">
                Anda belum mendaftarkan satupun category dan tag, diharapkan mengisi terlebih dahulu karna akan dibutuhkan dalam pembuatan artikel
              </div>
          </div>
        <?php endif; ?>
        <div class="row">
            <div class="card col-12">
              <div class="card-block">
                <h4 class="card-title">Tambah Artikel</h4>
                <br>
                <form action="<?php echo e(route('admin.artikel.store')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                    <label class="form-control-label"><b>Judul Artikel</b></label>
                    <input type="text" class="form-control" placeholder="Ex: Seorang warga baru-baru ini telah dijemput oleh sang malaikat maut dalam perjalanan pulangnya" name="title" required>
                  </div>
                  <div class="form-group">
                    <label class="form-control-label col-12" style="padding-left: 0"><b>Gambar Cover</b></label>
                    <img src="<?php echo e(asset('images/post-img/noimg.png')); ?>" id="showgambar" class="img-responsive" style="max-width: 300px; max-height: 300px;" />
                  </div>
                  <div class="form-group">
                    <input id="gambar_post" class="col-12" name="image" type="file" style="padding-left: 0" />
                    <small>Cover dapat dikosongkan kalau memang tidak ada gambar cover untuk post nya</small>
                  </div>
                  <div class="form-group">
                    <div id="progress-wrp" style="display: none"><div class="progress-bar"></div ><div class="status">0%</div></div>
                  </div>
                  <div class="form-group summernote">
                    <label class="form-control-label"><b>Konten Artikel</b></label>
                    <textarea name="content" id="content" style="resize: none"></textarea>
                  </div>
                  <div class="form-group">
                    <label class="form-control-label"><b>Kategori Artikel</b></label>
                    <select name="category_id" class="form-control" required>
                      <option value="" hidden selected>Pilih Kategori</option>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label class="form-control-label"><b>Tag Artikel</b></label>
                    <select multiple="multiple" name="tag_id[]" class="form-control" required>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small>Jika ingin memilih lebih dari 1 tag, silahkan pilih sambil ditekan tombol 'CTRL' di keyboard</small>
                  </div>
                  <div class="form-group">
                    <label class="form-control-label col-12" style="padding-left: 0 !important"><b>Status Post</b></label>
                    <label class="custom-control custom-checkbox">
                      <input type="checkbox" name="aired" value="1" class="custom-control-input">
                      <span class="custom-control-indicator"></span>
                      <span class="custom-control-description">Langsung Diterbitkan</span>
                    </label>
                    <br>
                    <small>Jika dicentang, maka post akan langsung diterbitkan di website setelah anda menyimpan post ini</small>
                  </div>
                  <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Tambahkan">
                  </div>
                </form>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pluginjs'); ?>
<!-- include summernote css/js-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.6/summernote.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.6/summernote.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
    $('#content').summernote({
      height: 500,
      callbacks: {
        onImageUpload: function(image) {
            uploadImage(image[0]);
        }
      },
      minHeight: 300,
      maxHeight: 500,
      focus: true,
      airMode: false,
      fontNames: ['Roboto', 'Calibri', 'Times New Roman', 'Arial'],
      fontNamesIgnoreCheck: ['Roboto', 'Calibri'],
      dialogsInBody: true,
      dialogsFade: true,
      disableDragAndDrop: false,
      popover: {
          air: [
              ['color', ['color']],
              ['font', ['bold', 'underline', 'clear']]
          ]
      },
    });
  });

  function uploadImage(image) {
      var data = new FormData();
      data.append("image", image);
      $.ajax({
        url: '/ajaximage',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
        cache: false,
        contentType: false,
        processData: false,
        data: data,
        type: "post",
        xhr: function(){
            //upload Progress
            var xhr = $.ajaxSettings.xhr();
            if (xhr.upload) {
                xhr.upload.addEventListener('progress', function(event) {
                    var percent = 0;
                    var position = event.loaded || event.position;
                    var total = event.total;
                    if (event.lengthComputable) {
                        percent = Math.ceil(position / total * 100);
                    }
                    //update progressbar
                    $('#progress-wrp').show();
                    $('#progress-wrp' +" .progress-bar").css("width", + percent +"%");
                    $('#progress-wrp' + " .status").text(percent +"%");

                    if (percent == 100) {
                      percent = 0;
                      $('#progress-wrp').hide();
                    }
                }, true);
            }
            return xhr;
        },
        success: function(url) {
            var image = $('<img>').attr('src', url);
            $('#content').summernote("insertNode", image[0]);
        },
        error: function(data) {
            console.log(data);
        }
    });
  }
</script>

<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#showgambar').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#gambar_post").change(function () {
        readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>