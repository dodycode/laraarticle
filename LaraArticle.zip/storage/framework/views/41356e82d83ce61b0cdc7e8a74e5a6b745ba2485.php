<?php $__env->startSection('content'); ?>
<div class="container wrapper py5 tab__container">
	<div class="category mb4">
		<header class="category__header">
			<h2 class="category__title">Kategori Artikel</h2>
		</header>
		<div class="gutter grid--2-col lg-grid--3-col grid--left">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a class="card col mb1 sm-mb2" href="<?php echo e(route('home.category', ['category' => $category->category])); ?>">
				<div class="card__content" style="padding: 0; padding-top: 48px; text-align: center">
					<h4><?php echo e($category->category); ?></h4>
				</div>
			</a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
	<?php echo e($categories->links('vendor.pagination.simple-cat-page')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>