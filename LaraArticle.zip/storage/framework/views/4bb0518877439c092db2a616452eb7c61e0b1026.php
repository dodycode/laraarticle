<?php $__env->startSection('content'); ?>
<!-- Breadcrumb -->
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Home</li>
</ol>
<?php if(count($inviteList) > 0): ?>
<div class="container-fluid">
  <div class="animated fadeIn">
    <div class="row">
      <div class="card col-lg-10 offset-lg-1 col-sm-12 col-xs-12 pl-0 pr-0">
        <h4 class="card-header text-center">Daftar Menunggu Persetujuan</h4>
        <div class="card-block">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>User Email</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $inviteList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inviteUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td scope="row"><?php echo e($loop->iteration); ?></td> <!-- No. index table (start from 1), bukan id -->
                <td><?php echo e($inviteUser->email); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <a href="<?php echo e(route('admin.invite.add')); ?>"><button class="btn btn-primary">Undang Admin Baru</button></a>
        </div>
      </div>
      <br>
      <div class="text-center">
          <?php echo e($inviteList->links('vendor.pagination.bootstrap-4')); ?>

      </div>
    </div>
  </div>
</div>
<?php else: ?>
<div class="container-fluid">
	<div class="animated fadeIn">
		<div class="row">
			<div class="alert alert-success col-12" role="alert">
			  Untuk saat ini, tidak ada daftar undangan admin yang masih menunggu persetujuan
			</div>
			<br>
			<a href="<?php echo e(route('admin.invite.add')); ?>"><button class="btn btn-primary">Undang Admin Baru</button></a>
		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>