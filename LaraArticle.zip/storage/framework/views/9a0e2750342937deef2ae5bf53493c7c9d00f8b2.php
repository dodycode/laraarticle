<?php $__env->startSection('content'); ?>
<div class="container wrapper">
	<div class="callout my1"></div>
	<div class="gutter">
		<div class="md-col md-col-7 lg-col-8">
			<?php if(count($posts) > 0): ?>
				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="card card--post mt0 mb3">
					<div class="post__image">
						<a href="<?php echo e(route('home.read', ['slug' => $post->slug])); ?>">
							<?php if($post->image !== null): ?>
							<img src="<?php echo e(asset('images/post-img/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>">
							<?php endif; ?>
						</a>
					</div>
					<div class="post__content truncate">
						<span class="label">
							<a href="<?php echo e(route('home.category', ['category' => $post->namaKategori->category])); ?>">
								<?php echo e($post->namaKategori->category); ?>

							</a>

							<span class="text--gray"> / </span>
							<span class="text--gray"><?php echo e($post->created_at->format('j F, Y')); ?></span>
						</span>
						<h2>
							<a href="<?php echo e(route('home.read', ['slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a>
						</h2>
						<p>
							<?php
				                //tinymce sub-string in grid view list
				                $konten = $post->content;
				                $konten = strip_tags(html_entity_decode($konten));
				                $panjangkata = 100;
				                if (mb_strlen($konten,'UTF-8')>$panjangkata)
				                {
				                   $konten = mb_substr($konten, 0, $panjangkata-3, 'UTF-8').'...';
				                };
				                echo "$konten";
				            ?>
						</p>
						<a class="truncate__link" href="<?php echo e(route('home.read', ['slug' => $post->slug])); ?>">Baca Selengkapnya..</a>
					</div>
					<div class="post__footer">
						<div class="post__author">
							<img class="author__image" src="<?php echo e(asset('images/user-pp/user.png')); ?>">
							<div class="author__content">
								<h4 class="author__name">By <a href="#">Someone</a></h4>
							</div>
						</div>
						<ul class="tags">
							<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="tag">
								<a href="#" class="tag__link"><?php echo e($tag->tag); ?></a>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
			<div class="alert alert--danger">
				<h4 class="alert__text center mt2">Tidak ada post yang berkategori ini!</h4>
			</div>
			<?php endif; ?>

			<?php echo e($posts->links('vendor.pagination.simple-default')); ?>

		</div>
		<div class="md-col md-col-5 lg-col-4 sidebar">
			<!-- Latest Post Widget -->
			<div class="widget-wrapper" style="margin-top: 0">
				<h3 class="widget-title">Latest Post</h3>
				<div class="widget">
					<ul id="recent-post" style="margin-left: -15px">
						<?php if(count($widgetPost) > 0): ?>
							<?php $__currentLoopData = $widgetPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li>
								<div class="item-thumbnail">
									<a href="<?php echo e(route('home.read', ['slug' => $post->slug])); ?>" class="thumbnail">
										<?php if($post->image !== null): ?>
										<span class="thumbnail-image" style="background-image: url('<?php echo e(asset('images/post-img/'.$post->image)); ?>')"></span>
										<?php else: ?>
										<span class="thumbnail-image" style="background-image: url('<?php echo e(asset('images/post-img/noimg.png')); ?>')"></span>
										<?php endif; ?>
									</a>
								</div>
								<div class="item-inner">
									<p class="item-category" style="margin-bottom: 4px">
										<a class="article-link" href="<?php echo e(route('home.read', ['slug' => $post->slug])); ?>">
											<i class="fa fa-folder" style="color: #999"></i> <?php echo e($post->namaKategori->category); ?>

										</a>
									</p>
									<p class="item-title">
										<a href="<?php echo e(route('home.read', ['slug' => $post->slug])); ?>" class="title">
											<?php echo e($post->title); ?>

										</a>
									</p>
								</div>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<div class="alert alert--danger">
								<h4 class="alert__text center mt2">Tidak ada Post akhir-akhir ini</h4>
							</div>
						<?php endif; ?>
					</ul>
				</div>
			</div>

			<!-- Categories Widget -->
			<div class="widget-wrapper">
				<h3 class="widget-title">Categories</h3>
				<div class="widget" style="padding-left: 20px; padding-right: 20px">
					<ul class="category-list" style="margin-left: -15px">
						<?php $__currentLoopData = $widgetCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="category-list-item" style="padding: 10px; width: 100%; border-bottom: 1px solid #f5f5f5">
							<a href="<?php echo e(route('home.category', ['category' => $category->category])); ?>">
								<?php echo e($category->category); ?>

							</a>
							<span class="category-list-count">
								<?php echo e($category->posts_count); ?>

							</span>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<br>
					<div class="center">
						<a href="<?php echo e(route('home.listcat')); ?>" class="btn btn-primary small" role="button">Lihat Kategori Lainnya</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>