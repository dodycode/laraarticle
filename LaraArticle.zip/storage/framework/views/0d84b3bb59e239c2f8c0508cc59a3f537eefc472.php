<?php $__env->startSection('content'); ?>
<!-- Breadcrumb -->
<ol class="breadcrumb">
    <li class="breadcrumb-item active">Home</li>
</ol>
<?php if(count($categories) > 0): ?>
<div class="container-fluid">
  <div class="animated fadeIn">
    <div class="row">
      <div class="card col-lg-10 offset-lg-1 col-sm-12 col-xs-12 pl-0 pr-0">
        <h4 class="card-header text-center">Categories</h4>
        <div class="card-block">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Category</th>
                <th class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td scope="row"><?php echo e($loop->iteration); ?></td> <!-- No. index table (start from 1), bukan id -->
                <td><?php echo e($category->category); ?></td>
                <td class="text-center">
                	<small>
			            <a href="<?php echo e(route('admin.category.edit', ['id' => $category->id])); ?>" class="btn btn-default btn-md">
			            	<i class="fa fa-pencil" aria-hidden="true"></i>
			            </a>
			            <button role="button" class="btn btn-default btn-md btn-nobg" data-href="<?php echo e(route('admin.category.delete', ['id' => $category->id])); ?>" data-toggle="modal" data-target="#konfirmasiHapus">
			            	<i class="fa fa-trash-o" aria-hidden="true"></i>
			            </button>
		            </small>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <a href="<?php echo e(route('admin.category.add')); ?>"><button class="btn btn-primary">Add New Category</button></a>
        </div>
      </div>
      <br>
      <div class="text-center">
          <?php echo e($categories->links('vendor.pagination.bootstrap-4')); ?>

      </div>
    </div>
  </div>
</div>
<?php else: ?>
<div class="container-fluid">
	<div class="animated fadeIn">
		<div class="row">
			<div class="alert alert-danger col-12" role="alert">
			  Tidak ada satupun category terdaftar
			</div>
			<br>
			<a href="<?php echo e(route('admin.category.add')); ?>"><button class="btn btn-primary">Add New Category</button></a>
		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pluginjs'); ?>
<!-- Delete Modal -->
<div class="modal fade" id="konfirmasiHapus" tabindex="-1" role="dialog" aria-labelledby="hapus" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Konfirmasi Hapus</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
			</div>

			<div class="modal-body">
				Apakah anda yakin ingin menghapus ini?
			</div>

			<div class="modal-footer">
	        	<button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
	        	<a class="btn btn-primary btn-ok">Iya</a>
	    	</div>
		</div>
	</div>
</div>

<script type="text/javascript">
    $('#konfirmasiHapus').on('show.bs.modal', function(e) {
        $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>