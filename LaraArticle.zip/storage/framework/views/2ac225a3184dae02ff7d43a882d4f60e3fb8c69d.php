<?php if($paginator->hasPages()): ?>
    <nav class="pagination">
        
        <?php if($paginator->onFirstPage()): ?>
            <a class="pagination__arrow arrow--left btn--disabled" href="<?php echo e($paginator->previousPageUrl()); ?>">
                <i class="fa fa-arrow-left" aria-hidden="true"></i> Back
            </a>
        <?php else: ?>
            <a class="pagination__arrow arrow--left" href="<?php echo e($paginator->previousPageUrl()); ?>">
                <i class="fa fa-arrow-left" aria-hidden="true"></i> Back
            </a>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a class="pagination__arrow arrow--right" href="<?php echo e($paginator->nextPageUrl()); ?>">
                Next <i class="fa fa-arrow-right" aria-hidden="true"></i>
            </a>
        <?php else: ?>
            <a class="pagination__arrow arrow--right btn--disabled" href="<?php echo e($paginator->nextPageUrl()); ?>">
               Next <i class="fa fa-arrow-right" aria-hidden="true"></i>
            </a>
        <?php endif; ?>
    </nav>
<?php endif; ?>
