<p>HAAIIIIII ^_^</p>

<p>Kamu diundang noh sama salah satu admin kita buat jadi Admin di sini..</p>

<p>Gimana? mau join ga, kalo mau <a href="{{ route('invite.register', $invite->token) }}">klik aja</a> disini</p>

<p>Entar habis ituh kamu ngisi data lengkapmu disana, seperti nama panggilanmu kek, pass akun mu</p>